#ifndef FAT32_H
#define FAT32_H

#include "base.h"

typedef struct {
	u32 part_lba;

	u32 fat_begin_lba;
	u32 cluster_begin_lba;

	u32 sectors_per_fat;
	u32 root_cluster;

	u16 bytes_per_sector;
	u8 sectors_per_cluster;
	u8 fat_count;
} Fat32;

typedef struct {
	char name[12];
	u8 attr;
	u32 cluster;
	u32 size;
} Fat32DirEntry;

typedef int (*Fat32DirIter)(const Fat32DirEntry *entry, void *ctx);

void read_n_lba(u32 lba, u8 *buf, u32 n);

int fat32_init(Fat32 *fs, u32 part_lba);
u32 fat32_cluster_to_lba(const Fat32 *fs, u32 cluster);
u32 fat32_get_cluster(const Fat32 *fs, u32 cluster);
int fat32_is_eoc(u32 cluster);

int fat32_make_83_name(const char *name, char out[11]);
int fat32_name_cmp(const char *name1, const char *name2);
int fat32_list_dir(const Fat32 *fs, u32 dir_cluster, Fat32DirIter iter, void *ctx);
int fat32_find_entry_info(const Fat32 *fs, u32 dir_cluster, const char *name,
			  Fat32DirEntry *entry);
int fat32_find_entry(const Fat32 *fs, u32 dir_cluster, const char *name,
		     u32 *entry_cluster);

#endif
