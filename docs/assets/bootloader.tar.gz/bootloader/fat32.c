#include "base.h"
#include "fat32.h"

void read_n_lba(u32 lba, u8 *buf, u32 n)
{
	for (u32 i = 0; i < n; i++) {
		read1lba(lba + i, buf + i * 512);
	}
}

int fat32_init(Fat32 *fs, u32 part_lba)
{
	u8 sec[512];

	read1lba(part_lba, sec);

	fs->part_lba = part_lba;

	fs->bytes_per_sector = le_read_16(sec + 11);
	fs->sectors_per_cluster = sec[13];
	u16 reserved_sectors = le_read_16(sec + 14);
	fs->fat_count = sec[16];
	fs->sectors_per_fat = le_read_32(sec + 36);
	fs->root_cluster = le_read_32(sec + 44);

	if (fs->bytes_per_sector != 512)
		return -2;
	if (fs->sectors_per_cluster == 0 || fs->fat_count == 0 ||
	    fs->sectors_per_fat == 0 || fs->root_cluster < 2)
		return -3;

	fs->fat_begin_lba = part_lba + reserved_sectors;

	fs->cluster_begin_lba = part_lba + reserved_sectors +
				fs->fat_count * fs->sectors_per_fat;

	return 0;
}

u32 fat32_cluster_to_lba(const Fat32 *fat32, const u32 cluster)
{
	return fat32->cluster_begin_lba +
	       (cluster - 2) * fat32->sectors_per_cluster;
}
u32 fat32_get_cluster(const Fat32 *fat32, u32 cluster)
{
	u8 sec[512];

	u32 fat_offset = cluster * 4;
	u32 fat_lba = fat32->fat_begin_lba + fat_offset / 512;
	u32 ent_offset = fat_offset % 512;

	read1lba(fat_lba, sec);

	return le_read_32(sec + ent_offset) & 0x0FFFFFFF;
}

int fat32_is_eoc(u32 cluster)
{
	return cluster >= 0x0FFFFFF8;
}

int fat32_name_cmp(const char *name1, const char *name2)
{
	for (int i = 0; i < 11; i++) {
		char c1 = name1[i];
		char c2 = name2[i];
		if (c1 >= 'a' && c1 <= 'z') {
			c1 -= 32;
		}
		if (c2 >= 'a' && c2 <= 'z') {
			c2 -= 32;
		}
		if (c1 != c2) {
			return c1 - c2;
		}
	}
	return 0;
}

static char fat32_upper(char c)
{
	if (c >= 'a' && c <= 'z')
		return c - ('a' - 'A');
	return c;
}

int fat32_make_83_name(const char *name, char out[11])
{
	u32 base_len = 0;
	u32 ext_len = 0;
	int in_ext = 0;

	for (u32 i = 0; i < 11; i++)
		out[i] = ' ';

	for (u32 i = 0; name[i] != '\0'; i++) {
		char c = name[i];

		if (c == '.') {
			if (in_ext)
				return -1;
			in_ext = 1;
			continue;
		}
		if (c == ' ')
			continue;

		if (in_ext) {
			if (ext_len >= 3)
				return -1;
			out[8 + ext_len++] = fat32_upper(c);
		} else {
			if (base_len >= 8)
				return -1;
			out[base_len++] = fat32_upper(c);
		}
	}

	if (base_len == 0)
		return -1;

	return 0;
}

static u32 fat32_entry_cluster(const u8 *entry)
{
	return ((u32)le_read_16(entry + 20) << 16) | le_read_16(entry + 26);
}

static void fat32_copy_name(const u8 *raw, char out[12])
{
	for (u32 i = 0; i < 11; i++)
		out[i] = (char)raw[i];
	out[11] = '\0';
}

static void fat32_fill_entry(const u8 *raw, Fat32DirEntry *entry)
{
	fat32_copy_name(raw, entry->name);
	entry->attr = raw[11];
	entry->cluster = fat32_entry_cluster(raw);
	entry->size = le_read_32(raw + 28);
}

int fat32_list_dir(const Fat32 *fat32, u32 dir_cluster, Fat32DirIter iter,
		   void *ctx)
{
	u8 sec[512];
	u32 cluster = dir_cluster;

	while (!fat32_is_eoc(cluster)) {
		u32 lba = fat32_cluster_to_lba(fat32, cluster);

		for (u8 i = 0; i < fat32->sectors_per_cluster; i++) {
			read1lba(lba + i, sec);
			for (u16 off = 0; off < 512; off += 32) {
				Fat32DirEntry entry;

				if (sec[off] == 0x00)
					return 0;
				if (sec[off] == 0xE5)
					continue;
				if ((sec[off + 11] & 0x0F) == 0x0F)
					continue;

				fat32_fill_entry(sec + off, &entry);
				if (iter && iter(&entry, ctx) != 0)
					return 1;
			}
		}

		cluster = fat32_get_cluster(fat32, cluster);
	}

	return 0;
}

typedef struct {
	char name[11];
	Fat32DirEntry *entry;
	int found;
} FindCtx;

static int fat32_find_iter(const Fat32DirEntry *entry, void *ctx)
{
	FindCtx *find = (FindCtx *)ctx;

	if (fat32_name_cmp(entry->name, find->name) != 0)
		return 0;

	*find->entry = *entry;
	find->found = 1;
	return 1;
}

int fat32_find_entry_info(const Fat32 *fat32, u32 dir_cluster,
			  const char *name, Fat32DirEntry *entry)
{
	FindCtx ctx;

	if (fat32_make_83_name(name, ctx.name) != 0)
		return -1;

	ctx.entry = entry;
	ctx.found = 0;
	fat32_list_dir(fat32, dir_cluster, fat32_find_iter, &ctx);

	return ctx.found ? 0 : -1;
}

int fat32_find_entry(const Fat32 *fat32, u32 dir_cluster, const char *name,
		     u32 *entry_cluster)
{
	Fat32DirEntry entry;

	if (fat32_find_entry_info(fat32, dir_cluster, name, &entry) != 0)
		return -1;

	*entry_cluster = entry.cluster;
	return 0;
}

