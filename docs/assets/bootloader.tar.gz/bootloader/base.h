#ifndef BASE_H
#define BASE_H

typedef int i32;
typedef unsigned int u32;
typedef unsigned char u8;
typedef unsigned short u16;

void read1lba(u32 lba, u8 *buf);
void debug_putc(char c);

#ifdef USER_MODE_TESTING
#include <stdio.h>
#include <stdlib.h>

__attribute__((noreturn, unused)) static void panic(const char *msg)
{
	fprintf(stderr, "Panic: %s\n", msg);
	exit(1);
}
#else
__attribute__((noreturn, naked, unused)) static void panic(const char *msg)
{
	(void)msg;
	__asm__ volatile("cli\n\t"
			 "hlt");
	__builtin_unreachable();
}
#endif

static inline u16 le_read_16(const u8 *addr)
{
	return (u16)addr[0] | ((u16)addr[1] << 8);
}

static inline u32 le_read_32(const u8 *addr)
{
	return (u32)addr[0] | ((u32)addr[1] << 8) | ((u32)addr[2] << 16) |
	       ((u32)addr[3] << 24);
}

#ifndef USER_MODE_TESTING
static inline void strcpy(char *dst, const char *src)
{
	while (*src) {
		*dst++ = *src++;
	}
	*dst = '\0';
}

static inline int memcmp(const void *s1, const void *s2, u32 n)
{
	const char *p1 = (const char *)s1;
	const char *p2 = (const char *)s2;
	for (u32 i = 0; i < n; i++) {
		if (p1[i] != p2[i])
			return p1[i] - p2[i];
	}
	return 0;
}
#endif

#endif
