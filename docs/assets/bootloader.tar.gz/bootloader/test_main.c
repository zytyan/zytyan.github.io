#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "base.h"
#include "fat32.h"

static FILE *disk;

void read1lba(u32 lba, u8 *buf)
{
	if (fseek(disk, (long)lba * 512L, SEEK_SET) != 0) {
		perror("fseek");
		exit(1);
	}
	if (fread(buf, 1, 512, disk) != 512) {
		perror("fread");
		exit(1);
	}
}

u32 find_fat32_partition(void)
{
	u8 sec[512];

	read1lba(0, sec);
	if (sec[510] != 0x55 || sec[511] != 0xAA) {
		panic("bad MBR signature");
	}

	for (u32 i = 0; i < 4; i++) {
		u8 *p = sec + 0x1BE + i * 16;
		u8 type = p[4];

		if (type == 0x0B || type == 0x0C)
			return le_read_32(p + 8);
	}

	panic("no FAT32 partition found");
}

static void print_83_name(const char name[12])
{
	char base[9];
	char ext[4];
	int base_end = 7;
	int ext_end = 2;

	memcpy(base, name, 8);
	memcpy(ext, name + 8, 3);
	base[8] = '\0';
	ext[3] = '\0';

	while (base_end >= 0 && base[base_end] == ' ')
		base[base_end--] = '\0';
	while (ext_end >= 0 && ext[ext_end] == ' ')
		ext[ext_end--] = '\0';

	if (ext[0] != '\0')
		printf("%s.%s", base, ext);
	else
		printf("%s", base);
}

static int print_entry(const Fat32DirEntry *entry, void *ctx)
{
	(void)ctx;

	if (entry->attr & 0x08)
		return 0;

	printf("%c ", (entry->attr & 0x10) ? 'd' : '-');
	printf("%10u  cluster=%-8u  ", entry->size, entry->cluster);
	print_83_name(entry->name);
	putchar('\n');

	return 0;
}

int main(int argc, char **argv)
{
	const char *image = argc > 1 ? argv[1] : "disk.img";
	Fat32 fs;
	Fat32DirEntry vmlinuz;
	u32 part_lba;

	disk = fopen(image, "rb");
	if (!disk) {
		fprintf(stderr, "open %s: %s\n", image, strerror(errno));
		return 1;
	}

	part_lba = find_fat32_partition();
	if (fat32_init(&fs, part_lba) != 0) {
		fprintf(stderr, "FAT32 init failed\n");
		return 1;
	}

	printf("FAT32 partition starts at LBA %u\n", fs.part_lba);
	printf("FAT starts at LBA %u, data starts at LBA %u\n",
	       fs.fat_begin_lba, fs.cluster_begin_lba);
	printf("root cluster %u, %u sector(s)/cluster\n\n", fs.root_cluster,
	       fs.sectors_per_cluster);

	printf("Root directory:\n");
	fat32_list_dir(&fs, fs.root_cluster, print_entry, NULL);

	if (fat32_find_entry_info(&fs, fs.root_cluster, "VMLINUZ", &vmlinuz) != 0) {
		fprintf(stderr, "\nVMLINUZ not found\n");
		return 1;
	}

	printf("\nFound VMLINUZ: cluster=%u size=%u bytes\n", vmlinuz.cluster,
	       vmlinuz.size);

	fclose(disk);
	return 0;
}
