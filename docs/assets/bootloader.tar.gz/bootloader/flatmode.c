#include "base.h"
#include "fat32.h"

#define LINUX_SETUP_LOAD_ADDR 0x90000u
#define LINUX_KERNEL_LOAD_ADDR 0x100000u
#define LINUX_CMDLINE_ADDR 0x98000u
#define SECTOR_SIZE 512u

static const char linux_cmdline[] =
	"earlycon=uart8250,io,0x3f8,115200 console=ttyS0,115200n8 "
	"earlyprintk=serial,ttyS0,115200 loglevel=8 root=/dev/sda2 ro";

void jump_linux(u32 entry, u32 boot_params);
void enter_unreal_mode(void);

u32 mbr_init()
{
	u8 sec[512];

	read1lba(0, sec);

	if (sec[510] != 0x55 || sec[511] != 0xAA) {
		panic("bad MBR signature");
	}

	for (u32 i = 0; i < 4; i++) {
		u8 *p = sec + 0x1BE + i * 16;
		u8 type = p[4];
		if (type == 0x0B || type == 0x0C) {
			return le_read_32(p + 8);
		}
	}
	panic("no FAT32 partition found");
}

static u8 read8(u32 addr)
{
	u8 value;

	__asm__ volatile("movb (%1), %0" : "=q"(value) : "r"(addr) : "memory");
	return value;
}

static u32 read32(u32 addr)
{
	return (u32)read8(addr) | ((u32)read8(addr + 1) << 8) |
	       ((u32)read8(addr + 2) << 16) | ((u32)read8(addr + 3) << 24);
}

static void write8(u32 addr, u8 value)
{
	__asm__ volatile("movb %1, (%0)" : : "r"(addr), "q"(value) : "memory");
}

static void write16(u32 addr, u16 value)
{
	write8(addr, value & 0xFF);
	write8(addr + 1, value >> 8);
}

static void write32(u32 addr, u32 value)
{
	write8(addr, value & 0xFF);
	write8(addr + 1, (value >> 8) & 0xFF);
	write8(addr + 2, (value >> 16) & 0xFF);
	write8(addr + 3, (value >> 24) & 0xFF);
}

static void load_file_to_memory(const Fat32 *fat32, u32 first_cluster, u32 size,
				u32 setup_bytes)
{
	u32 cluster = first_cluster;
	u32 done = 0;

	while (!fat32_is_eoc(cluster) && done < size) {
		u32 lba = fat32_cluster_to_lba(fat32, cluster);

		for (u8 i = 0; i < fat32->sectors_per_cluster && done < size;
		     i++) {
			u32 dest;

			if (done < setup_bytes) {
				dest = LINUX_SETUP_LOAD_ADDR + done;
			} else {
				dest = LINUX_KERNEL_LOAD_ADDR + done -
				       setup_bytes;
			}

			read1lba(lba + i, (u8 *)dest);
			done += SECTOR_SIZE;
		}

		cluster = fat32_get_cluster(fat32, cluster);
	}

	if (done < size)
		panic("short FAT chain while loading kernel");
}

static void prepare_linux_boot_params(void)
{
	u32 i = 0;
	write16(LINUX_SETUP_LOAD_ADDR + 0x1FA, 0xFFFF); /* normal VGA */
	write8(LINUX_SETUP_LOAD_ADDR + 0x210, 0xFF); /* unknown bootloader */
	write8(LINUX_SETUP_LOAD_ADDR + 0x211,
	       read8(LINUX_SETUP_LOAD_ADDR + 0x211) | 0x80); /* CAN_USE_HEAP */
	write16(LINUX_SETUP_LOAD_ADDR + 0x224, 0xFE00);
	strcpy((char *)LINUX_CMDLINE_ADDR, linux_cmdline);
	write8(LINUX_CMDLINE_ADDR + i, '\0');
	write32(LINUX_SETUP_LOAD_ADDR + 0x228, LINUX_CMDLINE_ADDR);
	write32(LINUX_SETUP_LOAD_ADDR + 0x218, 0); /* no initrd */
	write32(LINUX_SETUP_LOAD_ADDR + 0x21C, 0);
	write32(LINUX_SETUP_LOAD_ADDR + 0x22C, 0);
	write32(LINUX_SETUP_LOAD_ADDR + 0x230, 0);
}

void load_linux(const Fat32 *fat32)
{
	Fat32DirEntry kernel;
	u32 setup_sectors;
	u32 setup_bytes;
	u32 code32_start;

	if (fat32_find_entry_info(fat32, fat32->root_cluster, "VMLINUZ",
				  &kernel) != 0)
		panic("VMLINUZ not found");
	debug_putc('f');

	read1lba(fat32_cluster_to_lba(fat32, kernel.cluster),
		 (u8 *)LINUX_SETUP_LOAD_ADDR);
	enter_unreal_mode();
	debug_putc('h');

	setup_sectors = read8(LINUX_SETUP_LOAD_ADDR + 0x1F1);
	if (setup_sectors == 0)
		setup_sectors = 4;
	setup_bytes = (setup_sectors + 1) * SECTOR_SIZE;

	if (setup_bytes >= kernel.size)
		panic("invalid Linux setup size");

	load_file_to_memory(fat32, kernel.cluster, kernel.size, setup_bytes);
	debug_putc('k');
	enter_unreal_mode();
	prepare_linux_boot_params();
	code32_start = read32(LINUX_SETUP_LOAD_ADDR + 0x214);
	if (code32_start == 0)
		code32_start = LINUX_KERNEL_LOAD_ADDR;
	debug_putc('j');
	jump_linux(code32_start, LINUX_SETUP_LOAD_ADDR);
}

void boot_main()
{
	u32 part_lba;
	Fat32 fat32;
	debug_putc('b');
	part_lba = mbr_init();
	debug_putc('m');
	if (fat32_init(&fat32, part_lba) != 0)
		panic("FAT32 init failed");
	debug_putc('i');
	load_linux(&fat32);
}
