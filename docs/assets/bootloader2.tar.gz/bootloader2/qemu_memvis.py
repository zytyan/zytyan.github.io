#!/usr/bin/env python3

import argparse
import json
import math
import os
import socket
import subprocess
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


MEM_SIZE = 0x100000  # 1 MiB


class QMP:
    def __init__(self, path: str):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(path)
        self.file = self.sock.makefile("rwb", buffering=0)

        # greeting
        self._read_msg()

        # enable capabilities
        self.cmd("qmp_capabilities")

    def close(self):
        self.file.close()
        self.sock.close()

    def _read_msg(self):
        while True:
            line = self.file.readline()
            if not line:
                raise RuntimeError("QMP connection closed")
            msg = json.loads(line.decode("utf-8"))
            if "event" in msg:
                continue
            return msg

    def cmd(self, execute: str, arguments: dict | None = None):
        req = {"execute": execute}
        if arguments is not None:
            req["arguments"] = arguments

        self.file.write((json.dumps(req) + "\n").encode("utf-8"))
        msg = self._read_msg()

        if "error" in msg:
            raise RuntimeError(msg["error"])
        return msg.get("return")


def make_red_image(
    data: bytes,
    output: str,
    width: int,
    block: int,
    label_every: int,
    left_margin: int,
):
    if block <= 0:
        raise ValueError("block must be positive")
    if width <= 0:
        raise ValueError("width must be positive")
    if label_every <= 0:
        raise ValueError("label_every must be positive")

    # 每 block 字节压成一个像素，用平均值表示强度
    values = []
    for i in range(0, len(data), block):
        chunk = data[i:i + block]
        avg = sum(chunk) // len(chunk)
        values.append(avg)

    height = math.ceil(len(values) / width)

    # 总画布：左边留空画偏移标签
    img = Image.new("RGB", (left_margin + width, height), (255, 255, 255))
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default()

    # 画像素区
    for i, v in enumerate(values):
        x = i % width
        y = i // width

        # 0 -> 白色, 255 -> 红色
        color = (255, 255 - v, 255 - v)
        img.putpixel((left_margin + x, y), color)

    # 画边界线
    draw.line([(left_margin, 0), (left_margin, height - 1)], fill=(180, 180, 180), width=1)

    # 每若干行标一次地址
    # 每一行代表 width * block 字节
    row_bytes = width * block

    for y in range(0, height, label_every):
        addr = y * row_bytes
        if addr >= len(data):
            break

        label = f"0x{addr:05X}"
        text_bbox = draw.textbbox((0, 0), label, font=font)
        text_h = text_bbox[3] - text_bbox[1]

        # 横线
        draw.line(
            [(left_margin - 5, y), (left_margin + width - 1, y)],
            fill=(220, 220, 220),
            width=1,
        )

        # 左侧文字
        draw.text(
            (4, max(0, y - text_h // 2)),
            label,
            fill=(0, 0, 0),
            font=font,
        )

    img.save(output)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--qmp", default="/tmp/qemu-qmp.sock", help="QMP unix socket path")
    parser.add_argument("-o", "--output", default="mem1m.png", help="output png")
    parser.add_argument("--width", type=int, default=1024, help="image width")
    parser.add_argument("--block", type=int, default=1, help="bytes per pixel")
    parser.add_argument("--stop", action="store_true", help="stop VM before dump, cont after")
    parser.add_argument("--label-every", type=int, default=64, help="label every N rows")
    parser.add_argument("--left-margin", type=int, default=90, help="left label margin in pixels")
    parser.add_argument("--open", action="store_true", help="open output after saving (for WSL)")
    args = parser.parse_args()

    dump_path = tempfile.mktemp(prefix="qemu-pmem-", suffix=".bin")

    qmp = QMP(args.qmp)
    try:
        if args.stop:
            qmp.cmd("stop")

        qmp.cmd("pmemsave", {
            "val": 0,
            "size": MEM_SIZE,
            "filename": dump_path,
        })

        if args.stop:
            qmp.cmd("cont")
    finally:
        qmp.close()

    p = Path(dump_path)
    if not p.exists():
        raise RuntimeError(f"dump file not created: {dump_path}")

    data = p.read_bytes()
    os.unlink(dump_path)

    if len(data) != MEM_SIZE:
        raise RuntimeError(f"dump size mismatch: got {len(data)}, want {MEM_SIZE}")

    make_red_image(
        data=data,
        output=args.output,
        width=args.width,
        block=args.block,
        label_every=args.label_every,
        left_margin=args.left_margin,
    )

    print(f"saved {args.output}")

    if args.open:
        try:
            out = Path(args.output).resolve()
            win_path = subprocess.check_output(
                ["wslpath", "-w", str(out)],
                text=True,
            ).strip()
            subprocess.run(["explorer.exe", win_path], check=False)
        except Exception as e:
            print(f"open failed: {e}")


if __name__ == "__main__":
    main()