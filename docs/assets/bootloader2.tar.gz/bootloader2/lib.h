#ifndef LIB_H
#define LIB_H

typedef long intptr_t;


void memcpy(void *dest, const void *src, intptr_t n);
void strcpy(char *dest, const char *src);
int strcmp(const char *s1, const char *s2);
void debug_puts(const char *str);

#endif // LIB_H