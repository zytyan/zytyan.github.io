#include "lib.h"
void protected_mode_C_entry()
{
    debug_puts("Hello, protected mode!\n");
    while (1) {
        __asm__ volatile("cli");
        __asm__ volatile("hlt");
    }
}