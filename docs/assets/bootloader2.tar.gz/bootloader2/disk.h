#include <stdint.h>

struct DAP {
	uint8_t size; // 0x10
	uint8_t reserved; // 0
	uint16_t count; // 要读的扇区数
	uint16_t offset; // 目标 offset
	uint16_t segment; // 目标 segment
	uint64_t lba; // 起始 LBA
};

struct Disk {
	int (*read)(uint64_t lba, uint16_t count, void *buffer);
};

struct File {
    uint64_t offset;
    
    int (*read)(void *buffer, uint32_t size);
};