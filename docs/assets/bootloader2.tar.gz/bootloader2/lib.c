#include "lib.h"

void memcpy(void *dest, const void *src, intptr_t n)
{
	for (intptr_t i = 0; i < n; i++) {
		((char *)dest)[i] = ((const char *)src)[i];
	}
}

void strcpy(char *dest, const char *src)
{
	while (*src) {
		*dest++ = *src++;
	}
	*dest = '\0'; // Null-terminate the destination string
}

int strcmp(const char *s1, const char *s2)
{
	while (*s1 && (*s1 == *s2)) {
		s1++;
		s2++;
	}
	return *(const unsigned char *)s1 - *(const unsigned char *)s2;
}